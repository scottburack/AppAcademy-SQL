class Post < ActiveRecord::Base

  validates :title, :body, :author_id, :presence => true

  belongs_to :author, :class_name => "User"
  has_many :comments, :foreign_key => :post_id

#### this method is inefficient since it makes a new query for each post
# def n_plus_one_post_comment_counts
#   posts = self.posts
#
#   post_comment_counts = {}
#   posts.each do |post|
#     post_comment_counts[post] = posts.comments.length
#   end
#
#   post_comment_counts
# end

  ### better method
  def includes_post_comment_counts
    posts = self.posts.includes(:comments)

    post_comment_counts = {}
    posts.each do |post|
      post_comment_counts[post] = post.comments.length
    end

    post_comment_counts
  end

end
