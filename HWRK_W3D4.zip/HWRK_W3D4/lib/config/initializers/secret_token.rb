# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
JoinsDemo::Application.config.secret_token = '4ad0d8f2ce0166665602eb416472757e63d6cd3e1063883fda16cacf8858b1a6a7e05c86f68846523dc98ddd6ef1d4bbbba0453ad2a7c094445db4a5e2aeb2d1'
